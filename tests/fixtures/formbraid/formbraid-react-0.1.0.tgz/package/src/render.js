import { jsx as _jsx } from "react/jsx-runtime";
import { pathSegments, resolveConstraints } from '@formbraid/core';
import { createContext, createElement, useContext, useMemo } from 'react';
import { FieldContext, useSelection } from './hooks.js';
export const InstanceContext = createContext(null);
function useInstance() {
    const instance = useContext(InstanceContext);
    if (instance === null) {
        throw new Error('A bound Formbraid component must be rendered inside its Form.');
    }
    return instance;
}
function registered(registry, name) {
    return Object.hasOwn(registry, name) ? registry[name] : undefined;
}
function renderComponent(component, props) {
    if (typeof component !== 'function' && (typeof component !== 'object' || component === null)) {
        throw new Error('The requested component is not registered with Formbraid.');
    }
    // Registry lookup is the single dynamic boundary; public bindings retain each component's exact props.
    return createElement(component, props);
}
function makeField(key) {
    return function BoundField(overrides) {
        const { definition, form } = useInstance();
        const field = Object.hasOwn(definition.fields, key) ? definition.fields[key] : undefined;
        if (field === undefined) {
            throw new Error(`Unknown field: ${key}`);
        }
        const context = useMemo(() => ({ session: form.session, name: field.name }), [form, field.name]);
        const selectRequired = useMemo(() => (state) => resolveConstraints(field.constraints, state.values).required, [field.constraints]);
        const required = useSelection(form.session, selectRequired);
        const instance = useInstance();
        return (_jsx(FieldContext, { value: context, children: renderComponent(registered(instance.fieldComponents, field.component), {
                ...field.props,
                label: field.label,
                ...(field.helpText === undefined ? {} : { helpText: field.helpText }),
                constraints: { ...field.constraints, required },
                ...overrides,
            }) }));
    };
}
function makeComponent(name) {
    return function BoundComponent(props) {
        const { formComponents } = useInstance();
        return renderComponent(registered(formComponents, name), props);
    };
}
function makeGroup(name, registry) {
    return function BoundGroup(overrides) {
        const { definition, form } = useInstance();
        const group = Object.hasOwn(definition.groups, name) ? definition.groups[name] : undefined;
        if (group === undefined) {
            throw new Error(`Unknown group: ${name}`);
        }
        return renderComponent(registered(registry, group.component), {
            ...group.props,
            ...(group.label === undefined ? {} : { label: group.label }),
            ...(group.helpText === undefined ? {} : { helpText: group.helpText }),
            ...overrides,
            form,
            fields: group.fields,
        });
    };
}
function insertField(tree, path, component) {
    const segments = pathSegments(path);
    let node = tree;
    for (const segment of segments) {
        let child = node.children.get(segment);
        if (child === undefined) {
            child = { children: new Map() };
            node.children.set(segment, child);
        }
        node = child;
    }
    if (node.field !== undefined) {
        throw new Error(`Duplicate bound field path: ${path}`);
    }
    node.field = { name: path, component };
}
function fieldTree(node, identities, enumerable = true) {
    // Sorting makes identities independent of definition field order.
    const entries = [...node.children];
    // oxlint-disable-next-line unicorn/no-array-sort -- Map entries own this new array; ES2022 is the package target.
    entries.sort(([left], [right]) => left.localeCompare(right));
    const children = entries.map(([name, child]) => [name, fieldTree(child, identities, name !== 'defaultProps')]);
    const paths = [
        ...(node.field === undefined ? [] : [node.field.name]),
        ...children.flatMap(([, child]) => child.paths),
    ];
    const properties = {};
    for (const [name, child] of children) {
        // React enumerates type.defaultProps when constructing an element. A data
        // namespace with that name must expose its bindings without injecting props.
        Object.defineProperty(properties, name, { value: child.binding, enumerable });
    }
    if (node.field === undefined) {
        return { binding: Object.freeze(properties), paths };
    }
    const { component } = node.field;
    if (children.length === 0) {
        return { binding: component, paths };
    }
    const binding = cached(identities.containers, JSON.stringify(paths), () => {
        function BoundContainer(props) {
            return createElement(component, props);
        }
        // Keep each layout's child properties immutable. Attaching them to the shared
        // field component would let suspended renders change another layout's tree.
        for (const [name, child] of children) {
            Object.defineProperty(BoundContainer, name, { value: child.binding, enumerable });
        }
        return Object.freeze(BoundContainer);
    });
    return { binding, paths };
}
function cached(cache, name, create) {
    let component = cache.get(name);
    if (component === undefined) {
        component = create();
        cache.set(name, component);
    }
    return component;
}
/** Rebuild layout membership while retaining component identities for unchanged names. */
export function createBindings(definition, options) {
    const { components, registry, submitComponent, identities } = options;
    const tree = { children: new Map() };
    const flat = new Map();
    for (const [name, field] of Object.entries(definition.fields).filter(([, candidate]) => !candidate.name.includes('*'))) {
        const component = cached(identities.fields, name, () => makeField(name));
        insertField(tree, name, component);
        flat.set(field.name, component);
    }
    const groups = Object.fromEntries(Object.keys(definition.groups).map((name) => [
        name,
        cached(identities.groups, name, () => makeGroup(name, registry)),
    ]));
    const formComponents = Object.fromEntries(components.map((name) => [name, cached(identities.components, name, () => makeComponent(name))]));
    const membership = new Map();
    for (const [name, group] of Object.entries(definition.groups)) {
        for (const path of Object.values(group.fields)) {
            membership.set(path, name);
        }
    }
    const placed = new Set();
    const automatic = [];
    for (const field of Object.values(definition.fields)) {
        const groupName = membership.get(field.name);
        const component = groupName === undefined ? flat.get(field.name) : groups[groupName];
        const identity = groupName === undefined ? `field:${field.name}` : `group:${groupName}`;
        if (component !== undefined && !placed.has(identity)) {
            automatic.push({ key: identity, component });
            placed.add(identity);
        }
    }
    if (submitComponent !== undefined && formComponents[submitComponent] !== undefined) {
        automatic.push({ key: `component:${submitComponent}`, component: formComponents[submitComponent] });
    }
    const fields = fieldTree(tree, identities).binding;
    return { fields, groups, components: formComponents, automatic };
}
export function eraseInstance(instance) {
    return instance;
}
export function typedBindings(bindings) {
    return bindings;
}
