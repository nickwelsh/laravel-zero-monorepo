import type { FormSession, FormState } from '@formbraid/core';
import type { FieldApi, FormApi } from './form-api.js';
type RuntimeSession = FormSession<Record<string, unknown>>;
export declare const FormContext: import("react").Context<FormApi<Record<string, unknown>, Record<string, unknown>, void, unknown, never, never> | null>;
export declare const FieldContext: import("react").Context<{
    readonly session: RuntimeSession;
    readonly name: string;
} | null>;
/** Cache selector output by equality so unrelated state updates do not render consumers. */
export declare function useSelection<T>(session: RuntimeSession, selector: (state: FormState<Record<string, unknown>>) => T, equal?: (previous: T, next: T) => boolean): T;
export declare function useFormContext<TValues extends object = object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never>(): FormApi<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>;
export declare function useFieldContext<TValue = unknown, TInput = TValue>(): FieldApi<TValue, TInput>;
export {};
