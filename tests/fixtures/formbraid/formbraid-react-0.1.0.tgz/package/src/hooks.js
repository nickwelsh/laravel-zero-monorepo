import { createContext, useContext, useMemo, useSyncExternalStore } from 'react';
export const FormContext = createContext(null);
export const FieldContext = createContext(null);
/** Cache selector output by equality so unrelated state updates do not render consumers. */
export function useSelection(session, selector, equal = Object.is) {
    const getSnapshot = useMemo(() => selectionSnapshot(session, selector, equal), [session, selector, equal]);
    return useSyncExternalStore(session.subscribe, getSnapshot, getSnapshot);
}
function selectionSnapshot(session, selector, equal) {
    let cache = undefined;
    return () => {
        const state = session.getSnapshot();
        if (cache?.state === state) {
            return cache.value;
        }
        const next = selector(state);
        cache = { state, value: cache !== undefined && equal(cache.value, next) ? cache.value : next };
        return cache.value;
    };
}
export function useFormContext() {
    const form = useContext(FormContext);
    if (form === null) {
        throw new Error('useFormContext must be used inside a Formbraid Form.');
    }
    return form;
}
export function useFieldContext() {
    const context = useContext(FieldContext);
    if (context === null) {
        throw new Error('useFieldContext must be used inside a Formbraid field.');
    }
    const { session, name } = context;
    const selector = useMemo(() => () => session.getField(name), [session, name]);
    const field = useSelection(session, selector, sameField);
    const actions = useMemo(() => ({
        name,
        setValue: (value) => {
            const next = typeof value === 'function'
                ? value(session.getField(name).value)
                : value;
            session.setValue(name, next);
        },
        touch: () => {
            session.touch(name);
        },
    }), [session, name]);
    return {
        ...actions,
        value: field.value,
        errors: field.errors,
        meta: { isTouched: field.touched, isDirty: field.dirty, isValid: field.errors.length === 0 },
    };
}
function sameField(previous, next) {
    return (Object.is(previous.value, next.value) &&
        previous.touched === next.touched &&
        previous.dirty === next.dirty &&
        previous.errors.length === next.errors.length &&
        previous.errors.every((error, index) => error === next.errors[index]));
}
