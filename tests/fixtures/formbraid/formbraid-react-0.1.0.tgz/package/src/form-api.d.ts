import type { FieldPath, FieldPathInput, FieldPathValue, FormSession, FormState, SubmissionResult } from '@formbraid/core';
import type { ReactNode } from 'react';
export interface FieldApi<TValue, TInput = TValue> {
    readonly name: string;
    readonly value: TValue;
    readonly errors: ReadonlyArray<string>;
    readonly meta: {
        readonly isTouched: boolean;
        readonly isDirty: boolean;
        readonly isValid: boolean;
    };
    readonly setValue: (value: TInput | ((previous: TValue) => TInput)) => void;
    readonly touch: () => void;
}
export type ReactFormState<TValues extends object, TSuccess = void, TError = unknown> = FormState<TValues, TSuccess, TError> & {
    readonly isSubmitting: boolean;
    readonly canSubmit: boolean;
};
export interface FormApi<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never> {
    readonly session: FormSession<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>;
    readonly getState: () => ReactFormState<TValues, TSuccess, TError>;
    readonly getFieldValue: <P extends FieldPath<TValues>>(name: P) => FieldPathValue<TValues, P>;
    readonly setFieldValue: <P extends FieldPath<TValues>>(name: P, value: FieldPathInput<TValues, P> | ((previous: FieldPathValue<TValues, P>) => FieldPathInput<TValues, P>)) => void;
    readonly touchField: (name: FieldPath<TValues>) => void;
    readonly reset: (values?: TValues) => void;
    readonly handleSubmit: () => Promise<SubmissionResult<TSuccess, TError>>;
    readonly cancel: () => void;
    readonly append: FormSession<TValues>['append'];
    readonly remove: FormSession<TValues>['remove'];
    readonly move: FormSession<TValues>['move'];
    readonly Subscribe: <T>(props: {
        readonly selector: (state: ReactFormState<TValues, TSuccess, TError>) => T;
        readonly children: (value: T) => ReactNode;
    }) => ReactNode;
    readonly Field: <P extends FieldPath<TValues>>(props: {
        readonly name: P;
        readonly children: (field: FieldApi<FieldPathValue<TValues, P>, FieldPathInput<TValues, P>>) => ReactNode;
    }) => ReactNode;
}
export declare function reactState<TValues extends object, TSuccess = void, TError = unknown>(state: FormState<TValues, TSuccess, TError>): ReactFormState<TValues, TSuccess, TError>;
/** Constructed once per mounted session; component identities never change on edits. */
export declare function createFormApi<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never>(session: FormSession<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>): FormApi<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>;
