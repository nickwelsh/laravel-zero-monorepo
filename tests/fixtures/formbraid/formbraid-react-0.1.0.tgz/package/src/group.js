import { jsx as _jsx } from "react/jsx-runtime";
/* oxlint-disable typescript/no-unsafe-type-assertion -- Slot projection is a checked mapping from statically typed parent paths to local group values. */
import { getValue, normalizePath } from '@formbraid/core';
import { useMemo } from 'react';
import { useSelection } from './hooks.js';
/** Map reusable local slots onto the owning form's paths without another state store. */
export function withFieldGroup(options) {
    return function FieldGroup(props) {
        const { form, fields, ...presentation } = props;
        // oxlint-disable-next-line unicorn/no-array-sort -- Object.entries owns this new array; ES2022 is the package target.
        const mappingKey = JSON.stringify(Object.entries(fields).sort(([left], [right]) => left.localeCompare(right)));
        const group = useMemo(() => createGroupApi(form, Object.fromEntries(JSON.parse(mappingKey))), [form, mappingKey]);
        return options.render({ ...options.props, ...presentation, group });
    };
}
function stableRecord(previous, next) {
    const keys = Object.keys(next);
    return keys.length === Object.keys(previous).length && keys.every((key) => Object.is(previous[key], next[key]))
        ? previous
        : Object.freeze(next);
}
function createGroupApi(form, fields) {
    const setRuntimeValue = form.setFieldValue;
    const mapping = fields;
    const path = (name) => {
        const [slot, ...tail] = normalizePath(name).split('.');
        const target = slot === undefined ? undefined : mapping[slot];
        if (target === undefined) {
            throw new Error(`Unknown field group slot: ${name}`);
        }
        // Session methods resolve aliases against current values. A mounted Field must
        // retain the raw path when an array later becomes a record with distinct keys.
        return [target, ...tail].join('.');
    };
    let previous = undefined;
    let projected = undefined;
    const project = (state) => {
        if (previous !== state || projected === undefined) {
            const values = Object.fromEntries(Object.entries(mapping).map(([slot, target]) => [slot, getValue(state.values, target)]));
            const baseline = Object.fromEntries(Object.entries(mapping).map(([slot, target]) => [slot, getValue(state.baseline, target)]));
            const errors = {};
            const metadata = {};
            for (const [slot, rawTarget] of Object.entries(mapping)) {
                const target = form.session.resolvePath(rawTarget);
                for (const [name, messages] of Object.entries(state.errors)) {
                    if (name === target || name.startsWith(`${target}.`)) {
                        errors[`${slot}${name.slice(target.length)}`] = messages;
                    }
                }
                for (const [name, meta] of Object.entries(state.fields)) {
                    if (name === target || name.startsWith(`${target}.`)) {
                        metadata[`${slot}${name.slice(target.length)}`] = meta;
                    }
                }
            }
            projected = Object.freeze({
                values: stableRecord((projected?.values ?? {}), values),
                baseline: stableRecord((projected?.baseline ?? {}), baseline),
                errors: stableRecord(projected?.errors ?? {}, errors),
                fields: stableRecord(projected?.fields ?? {}, metadata),
                isDirty: Object.values(mapping).some((target) => form.session.getField(target).dirty),
            });
            previous = state;
        }
        return projected;
    };
    function Subscribe({ selector, children, }) {
        const select = useMemo(() => (state) => selector(project(state)), [selector]);
        return children(useSelection(form.session, select));
    }
    function Field({ name, children, }) {
        return _jsx(form.Field, { name: path(name), children: children });
    }
    return {
        getState: () => project(form.session.getSnapshot()),
        getFieldValue: (name) => form.getFieldValue(path(name)),
        setFieldValue: (name, value) => {
            setRuntimeValue(path(name), value);
        },
        touchField: (name) => {
            form.touchField(path(name));
        },
        Subscribe,
        Field,
    };
}
