import type { FieldDefinition, GroupDefinition, SubmissionDriver } from '@formbraid/core';
import type { ReactNode } from 'react';
import type { ComponentRegistry, FormProps, UseForm } from './types.js';
export interface FormbraidOptions<TFields extends ComponentRegistry, TComponents extends ComponentRegistry, TGroups extends ComponentRegistry> {
    readonly fieldComponents: TFields;
    readonly formComponents: TComponents;
    readonly fieldGroups?: TGroups;
    readonly submissions?: Readonly<Record<string, SubmissionDriver>>;
    readonly submitComponent?: keyof TComponents & string;
}
export declare function createFormbraid<const TFieldComponents extends ComponentRegistry, const TComponents extends ComponentRegistry, const TGroupComponents extends ComponentRegistry = Record<string, never>>(config: FormbraidOptions<TFieldComponents, TComponents, TGroupComponents>): {
    Form: <TValues extends object, const TFields extends Readonly<Record<string, FieldDefinition>>, const TGroups extends Readonly<Record<string, GroupDefinition>>, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never>(props: FormProps<TValues, TFields, TGroups, TFieldComponents, TComponents, TGroupComponents, TOutput, TSuccess, TError, TServices, TSchemaServices>) => ReactNode;
    useForm: UseForm;
};
