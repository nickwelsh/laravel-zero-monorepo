import type { FieldPath, FieldPathInput, FieldPathValue } from '@formbraid/core';
import type { ReactNode } from 'react';
import type { FormApi } from './form-api.js';
type CompatiblePath<TParent extends object, TValue> = {
    [P in FieldPath<TParent>]: [FieldPathValue<TParent, P>] extends [TValue] ? [TValue] extends [FieldPathValue<TParent, P>] ? [FieldPathInput<TParent, P>] extends [TValue] ? [TValue] extends [FieldPathInput<TParent, P>] ? P : never : never : never : never;
}[FieldPath<TParent>];
export type GroupFields<TValues extends object, TParent extends object> = {
    readonly [K in keyof TValues & (string | number) as `${K}`]: CompatiblePath<TParent, TValues[K]>;
};
export interface GroupState<TValues extends object> {
    readonly values: TValues;
    readonly baseline: TValues;
    readonly fields: Readonly<Record<string, {
        readonly touched: boolean;
    }>>;
    readonly errors: Readonly<Record<string, ReadonlyArray<string>>>;
    readonly isDirty: boolean;
}
export interface GroupApi<TValues extends object> {
    readonly getState: () => GroupState<TValues>;
    readonly getFieldValue: FormApi<TValues>['getFieldValue'];
    readonly setFieldValue: FormApi<TValues>['setFieldValue'];
    readonly touchField: FormApi<TValues>['touchField'];
    readonly Field: FormApi<TValues>['Field'];
    readonly Subscribe: <T>(props: {
        readonly selector: (state: GroupState<TValues>) => T;
        readonly children: (value: T) => ReactNode;
    }) => ReactNode;
}
/** Map reusable local slots onto the owning form's paths without another state store. */
export declare function withFieldGroup<TValues extends object, TProps extends object>(options: {
    readonly defaultValues: TValues;
    readonly props: TProps;
    readonly render: (props: Partial<TProps> & {
        readonly group: GroupApi<TValues>;
    }) => ReactNode;
}): <TParent extends object, TOutput, TSuccess, TError, TServices, TSchemaServices>(props: Partial<TProps> & {
    readonly form: FormApi<TParent, TOutput, TSuccess, TError, TServices, TSchemaServices>;
    readonly fields: GroupFields<TValues, TParent>;
}) => ReactNode;
export {};
