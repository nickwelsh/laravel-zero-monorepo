import { jsx as _jsx } from "react/jsx-runtime";
import { useMemo } from 'react';
import { FieldContext, useFieldContext, useSelection } from './hooks.js';
export function reactState(state) {
    const isSubmitting = state.execution.status === 'validating' || state.execution.status === 'submitting';
    return Object.freeze({ ...state, isSubmitting, canSubmit: !isSubmitting });
}
function FieldChild({ children }) {
    return children(useFieldContext());
}
/** Constructed once per mounted session; component identities never change on edits. */
export function createFormApi(session) {
    const runtime = session;
    const setRuntimeValue = runtime.setValue;
    function Subscribe({ selector, children, }) {
        const select = useMemo(() => (state) => selector(reactState(state)), [selector]);
        return children(useSelection(runtime, select));
    }
    function Field({ name, children, }) {
        const context = useMemo(() => ({ session: runtime, name }), [name]);
        return (_jsx(FieldContext, { value: context, children: _jsx(FieldChild, { children: children }) }));
    }
    return {
        session,
        getState: () => reactState(session.getSnapshot()),
        getFieldValue: (name) => session.getField(name).value,
        setFieldValue: (name, value) => {
            setRuntimeValue(name, typeof value === 'function'
                ? value(session.getField(name).value)
                : value);
        },
        touchField: (name) => {
            session.touch(name);
        },
        reset: (values) => {
            session.reset(values);
        },
        handleSubmit: session.submit,
        cancel: session.cancel,
        append: session.append,
        remove: session.remove,
        move: session.move,
        Subscribe,
        Field,
    };
}
