import type { FieldDefinition, FormDefinition, GroupDefinition } from '@formbraid/core';
import type { ComponentType } from 'react';
import type { ComponentRegistry, LayoutBindings } from './types.js';
import type { FormApi } from './form-api.js';
export interface RuntimeInstance {
    readonly definition: FormDefinition;
    readonly form: FormApi<Record<string, unknown>>;
    readonly fieldComponents: ComponentRegistry;
    readonly formComponents: ComponentRegistry;
}
export interface RuntimeBindings {
    readonly fields: Record<string, unknown>;
    readonly components: Record<string, ComponentType<Record<string, unknown>>>;
    readonly groups: Record<string, ComponentType<Record<string, unknown>>>;
    readonly automatic: ReadonlyArray<{
        readonly key: string;
        readonly component: ComponentType<Record<string, unknown>>;
    }>;
}
export interface BindingIdentityCache {
    readonly fields: Map<string, ComponentType<Record<string, unknown>>>;
    readonly containers: Map<string, ComponentType<Record<string, unknown>>>;
    readonly groups: Map<string, ComponentType<Record<string, unknown>>>;
    readonly components: Map<string, ComponentType<Record<string, unknown>>>;
}
export declare const InstanceContext: import("react").Context<RuntimeInstance | null>;
/** Rebuild layout membership while retaining component identities for unchanged names. */
export declare function createBindings(definition: FormDefinition, options: {
    readonly components: ReadonlyArray<string>;
    readonly registry: ComponentRegistry;
    readonly identities: BindingIdentityCache;
    readonly submitComponent?: string;
}): RuntimeBindings;
export declare function eraseInstance(instance: unknown): RuntimeInstance;
export declare function typedBindings<TFields extends Readonly<Record<string, FieldDefinition>>, TGroups extends Readonly<Record<string, GroupDefinition>>, TFieldComponents extends ComponentRegistry, TComponents extends ComponentRegistry, TGroupComponents extends ComponentRegistry>(bindings: RuntimeBindings): LayoutBindings<TFields, TGroups, TFieldComponents, TComponents, TGroupComponents>;
