import { jsx as _jsx } from "react/jsx-runtime";
import { createFormSession } from '@formbraid/core';
import { createElement, useInsertionEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createBindings, eraseInstance, typedBindings, InstanceContext } from './render.js';
import { createFormApi } from './form-api.js';
import { FormContext } from './hooks.js';
function notify(callback, value) {
    try {
        // oxlint-disable-next-line promise/prefer-await-to-callbacks -- Lifecycle notifications are synchronous callbacks.
        callback(value);
    }
    catch (error) {
        globalThis.reportError(error);
    }
}
function descriptorDriver(descriptor, drivers) {
    if (descriptor.version !== undefined && descriptor.version !== 1) {
        throw new Error('Unsupported Formbraid form descriptor version.');
    }
    const { driver, submit } = descriptor.submission;
    if (submit !== undefined && driver !== undefined) {
        throw new Error('A form submission must provide either a driver or a callback.');
    }
    if (typeof driver !== 'string' || drivers === undefined || !Object.hasOwn(drivers, driver)) {
        return undefined;
    }
    return drivers[driver];
}
function resolveForm(input, options, drivers) {
    const bound = 'definition' in input ? input : undefined;
    const definition = 'definition' in input ? input.definition : input;
    const submission = bound?.submission;
    const registeredDriver = bound === undefined ? undefined : descriptorDriver(bound, drivers);
    const driver = options.submission ?? registeredDriver;
    const defaults = options.defaultValues ?? (bound !== undefined && 'defaultValues' in bound ? bound.defaultValues : undefined);
    // Explicit per-form executors replace the descriptor's submission strategy.
    const submit = options.operation === undefined && options.submission === undefined ? submission?.submit : undefined;
    // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- Public options retain the conditional runner requirement; rebuilding optional keys preserves it.
    return {
        definition,
        ...(defaults === undefined ? {} : { defaultValues: defaults }),
        ...(options.operation === undefined ? {} : { operation: options.operation }),
        ...(submit === undefined ? {} : { submit }),
        ...(options.run === undefined ? {} : { run: options.run }),
        ...(submission?.binding === undefined ? {} : { binding: submission.binding }),
        ...(driver === undefined ? {} : { driver }),
    };
}
export function createFormbraid(config) {
    const cache = new WeakMap();
    const identities = {
        fields: new Map(),
        containers: new Map(),
        groups: new Map(),
        components: new Map(),
    };
    const groupRegistry = config.fieldGroups ?? {};
    function useFormImplementation(input, options = {}) {
        const sessionOptions = resolveForm(input, options, config.submissions);
        const { definition } = sessionOptions;
        // oxlint-disable-next-line react/hook-use-state -- Sessions are constructed once; their own subscriptions publish state.
        const [session] = useState(() => createFormSession(sessionOptions));
        const lifetime = useRef({ mounted: false, options });
        // oxlint-disable-next-line react/hook-use-state -- The form API and its component identities are mount-only.
        const [form] = useState(() => createFormApi(session));
        // Install only committed options, before descendants can submit from layout effects.
        useInsertionEffect(() => {
            lifetime.current.options = options;
            session.updateOptions({
                ...sessionOptions,
                onResult: (result) => {
                    const { current } = lifetime;
                    if (current.mounted && current.options.onResult !== undefined) {
                        notify(current.options.onResult, result);
                    }
                    else if (!current.mounted && result.status !== 'cancelled') {
                        const { execution } = session.getSnapshot();
                        if (execution.status === result.status) {
                            // A supplied runner may fail synchronously in a child's layout effect.
                            // Deliver after activation only while that terminal execution remains current.
                            queueMicrotask(() => {
                                const observer = current.options.onResult;
                                if (current.mounted &&
                                    observer !== undefined &&
                                    session.getSnapshot().execution === execution) {
                                    notify(observer, result);
                                }
                            });
                        }
                    }
                },
            });
        });
        useInsertionEffect(() => {
            const { current } = lifetime;
            // oxlint-disable-next-line eslint/init-declarations -- No progress is available before a submission.
            let progress;
            const unsubscribe = session.subscribe(() => {
                const next = session.getSnapshot().progress;
                if (next === progress) {
                    return;
                }
                // Observers can publish synchronously; retain their newer or cleared progress.
                progress = next;
                if (next !== undefined && lifetime.current.options.onProgress !== undefined) {
                    const deliver = () => {
                        const observer = lifetime.current.options.onProgress;
                        if (current.mounted && observer !== undefined && session.getSnapshot().progress === next) {
                            notify(observer, next);
                        }
                    };
                    if (current.mounted) {
                        deliver();
                    }
                    else {
                        // Child layout effects precede the owner's setup. Initially hidden Activity
                        // owners never run that setup; canceled/replaced progress must not replay.
                        queueMicrotask(deliver);
                    }
                }
            });
            return () => {
                current.mounted = false;
                unsubscribe();
            };
        }, [session, lifetime]);
        useLayoutEffect(() => {
            // StrictMode replays layout effects without replaying insertion effects.
            const { current } = lifetime;
            current.mounted = true;
            return () => {
                current.mounted = false;
                session.cancel();
            };
        }, [session, lifetime]);
        return useMemo(() => ({ definition, form, cancel: session.cancel }), [definition, form, session]);
    }
    // The public overloads restrict omitted options to service-free definitions.
    // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- TypeScript erases service defaults while comparing generic overload returns; the input overload keeps serviceful definitions paired with a runner.
    const useForm = useFormImplementation;
    function render(instance, props) {
        const { form: _source, children, defaultValues: _defaults, submission: _submission, onResult: _result, onProgress: _progress, operation: _operation, run: _run, ...html } = props;
        const runtime = eraseInstance({
            ...instance,
            fieldComponents: config.fieldComponents,
            formComponents: config.formComponents,
        });
        let byGroups = cache.get(instance.definition.fields);
        if (byGroups === undefined) {
            byGroups = new WeakMap();
            cache.set(instance.definition.fields, byGroups);
        }
        let bindings = byGroups.get(instance.definition.groups);
        if (bindings === undefined) {
            bindings = createBindings(runtime.definition, {
                components: Object.keys(config.formComponents),
                registry: groupRegistry,
                identities,
                submitComponent: config.submitComponent ?? 'SubmitButton',
            });
            byGroups.set(instance.definition.groups, bindings);
        }
        const content = children === undefined
            ? bindings.automatic.map(({ component, key }) => createElement(component, { key }))
            : children(typedBindings(bindings));
        return (_jsx(InstanceContext, { value: runtime, children: _jsx(FormContext, { value: runtime.form, children: _jsx("form", { ...html, noValidate: true, onSubmit: (event) => {
                        event.preventDefault();
                        event.stopPropagation();
                        void instance.form.handleSubmit();
                    }, children: content }) }) }));
    }
    function DefinitionForm(props) {
        const instance = useForm(props.form, props);
        return render(instance, props);
    }
    function Form(props) {
        if ('form' in props.form) {
            return render(props.form, props);
        }
        return _jsx(DefinitionForm, { ...props, form: props.form });
    }
    return { Form, useForm };
}
