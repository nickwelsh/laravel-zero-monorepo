import type { FieldDefinition } from './contracts.js';
export declare function isPathSegment(segment: string): boolean;
export declare function pathSegments(path: string): Array<string>;
export declare function normalizeSegment(segment: string, isArray: boolean): string;
export declare function getValue(values: unknown, path: string): unknown;
export declare function normalizePath(path: string, values?: unknown, isAbsentArray?: (prefix: ReadonlyArray<string>) => boolean): string;
/** Infer absent containers from declared defaults and Laravel field metadata. */
export declare function definitionArrayAt(definition: {
    readonly defaultValues: object;
    readonly fields: Readonly<Record<string, FieldDefinition>>;
}, prefix: ReadonlyArray<string>): boolean;
export declare function titleCase(path: string): string;
