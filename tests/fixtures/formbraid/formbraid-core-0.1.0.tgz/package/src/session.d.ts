import { Effect, Scope } from 'effect';
import type { FieldDefinition, FormDefinition, GroupDefinition, JsonValue, Schema, SubmissionDriver, SubmissionCallback, SubmissionCallbackContext, SubmissionResult, UploadProgress } from './contracts.js';
type Atomic = string | number | boolean | bigint | symbol | null | undefined | Date | Blob | ReadonlyMap<unknown, unknown> | ReadonlySet<unknown>;
type JoinPath<A extends string, B extends string> = B extends `[${string}` ? `${A}${B}` : `${A}.${B}`;
type NestedPaths<A extends string, T, D extends ReadonlyArray<unknown>> = T extends unknown ? JoinPath<A, Paths<T, D>> : never;
type KeyPath<K extends string | number> = K extends number ? `${K}` | `[${K}]` : K;
type Paths<T, D extends ReadonlyArray<unknown> = []> = D['length'] extends 8 ? never : T extends Atomic ? never : T extends ReadonlyArray<infer I> ? `${number}` | `[${number}]` | NestedPaths<`${number}`, I, [...D, 0]> | NestedPaths<`[${number}]`, I, [...D, 0]> : {
    [K in keyof T & (string | number)]: KeyPath<K> | NestedPaths<KeyPath<K>, NonNullable<T[K]>, [...D, 0]>;
}[keyof T & (string | number)];
export type FieldPath<T> = Paths<T>;
type IndexKey<K extends string> = K extends `0${infer Rest}` ? (Rest extends '' ? '0' : IndexKey<Rest>) : K;
type ObjectKey<T, K extends string> = K extends keyof T ? K : K extends `${infer N extends number}` ? `${N}` extends K ? N extends keyof T ? N : never : never : never;
type SegmentValue<T, K extends string> = T extends null | undefined ? never : T extends ReadonlyArray<infer I> ? K extends `${number}` ? IndexKey<K> extends keyof T ? T[IndexKey<K>] : IndexKey<K> extends `${infer Index extends number}` ? T[Index] : I : K extends keyof T ? T[K] : never : T[ObjectKey<T, K> & keyof T];
type ExplicitKeys<T> = keyof {
    [K in keyof T as string extends K ? never : number extends K ? never : symbol extends K ? never : K]: unknown;
};
type SegmentRead<T, K extends string> = T extends unknown ? [SegmentValue<T, K>] extends [never] ? undefined : T extends ReadonlyArray<unknown> ? IndexKey<K> extends keyof T ? SegmentValue<T, K> : SegmentValue<T, K> | undefined : ObjectKey<T, K> extends ExplicitKeys<T> ? SegmentValue<T, K> : SegmentValue<T, K> | undefined : never;
type DotPath<P extends string> = P extends `${infer A}[${infer I}]${infer Rest}` ? DotPath<`${A extends '' ? '' : `${A}.`}${I}${Rest}`> : P;
type PathValue<T, P extends string> = P extends `${infer A}.${infer Rest}` ? PathValue<SegmentRead<T, A>, Rest> : SegmentRead<T, P>;
export type FieldPathValue<T, P extends string> = PathValue<T, DotPath<P>>;
type PathInput<T, P extends string> = P extends `${infer A}.${infer Rest}` ? PathInput<SegmentValue<T, A>, Rest> : SegmentValue<T, P>;
export type FieldPathInput<T, P extends string> = PathInput<T, DotPath<P>>;
type ArrayItem<T> = T extends ReadonlyArray<infer I> ? I : never;
type IsTuple<T> = T extends ReadonlyArray<unknown> ? number extends T['length'] ? Extract<keyof T, `${number}`> extends never ? T extends readonly [...ReadonlyArray<unknown>, unknown] ? true : false : true : true : false;
/** Structural helpers operate on dynamic arrays; tuple slots and lengths are fixed by their type. */
type ArrayEditPath<T, P extends string> = [Extract<FieldPathInput<T, P>, ReadonlyArray<unknown>>] extends [never] ? never : true extends IsTuple<FieldPathInput<T, P>> ? never : P;
export interface FieldState<TValue = unknown> {
    readonly value: TValue;
    readonly touched: boolean;
    readonly dirty: boolean;
    readonly errors: ReadonlyArray<string>;
}
export type ExecutionState<TSuccess = void, TError = unknown> = {
    readonly status: 'idle' | 'validating' | 'submitting';
} | SubmissionResult<TSuccess, TError>;
export interface FormState<TValues extends object, TSuccess = void, TError = unknown> {
    readonly values: TValues;
    readonly baseline: TValues;
    readonly fields: Readonly<Record<string, {
        readonly touched: boolean;
    }>>;
    readonly errors: Readonly<Record<string, ReadonlyArray<string>>>;
    readonly execution: ExecutionState<TSuccess, TError>;
    readonly progress: UploadProgress | undefined;
    readonly isDirty: boolean;
    readonly submitCount: number;
}
export type OperationContext = SubmissionCallbackContext;
export type FormOperation<TOutput, TSuccess = void, TError = never, TServices = never> = (output: TOutput, context: OperationContext) => Effect.Effect<TSuccess, TError, TServices>;
export type EffectRunner<TServices = never> = <A, E>(effect: Effect.Effect<A, E, TServices>, options: {
    readonly signal: AbortSignal;
}) => Promise<A>;
interface SessionOptionsBase<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never> {
    readonly definition: FormDefinition<TValues, Readonly<Record<string, FieldDefinition>>, Readonly<Record<string, GroupDefinition>>, TOutput, TSchemaServices>;
    readonly defaultValues?: TValues;
    readonly schema?: Schema<TValues, TOutput, TSchemaServices>;
    readonly operation?: FormOperation<TOutput, TSuccess, TError, TServices>;
    readonly submit?: SubmissionCallback<TOutput, TSuccess, TError>;
    readonly driver?: SubmissionDriver;
    readonly binding?: JsonValue;
    readonly onResult?: (result: SubmissionResult<NoInfer<TSuccess>, NoInfer<TError>>) => void;
}
export type SessionOptions<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never> = SessionOptionsBase<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices> & ([TSuccess] extends [ReturnType<() => void>] ? [unknown] extends [TError] ? {
    readonly operation?: FormOperation<TOutput, TSuccess, TError, TServices>;
} : {
    readonly operation: FormOperation<TOutput, TSuccess, TError, TServices>;
} | {
    readonly submit: SubmissionCallback<TOutput, TSuccess, TError>;
} : {
    readonly operation: FormOperation<TOutput, TSuccess, TError, TServices>;
} | {
    readonly submit: SubmissionCallback<TOutput, TSuccess, TError>;
}) & ([Exclude<TServices | TSchemaServices, Scope.Scope>] extends [never] ? {
    readonly run?: EffectRunner<Exclude<TServices | TSchemaServices, Scope.Scope>>;
} : {
    readonly run: EffectRunner<Exclude<TServices | TSchemaServices, Scope.Scope>>;
});
export interface FormSession<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never> {
    readonly getSnapshot: () => FormState<TValues, TSuccess, TError>;
    /** Resolve aliases using this session's draft and encoded container shapes. */
    readonly resolvePath: (path: string) => string;
    readonly subscribe: (listener: () => void) => () => void;
    readonly getField: <P extends FieldPath<TValues>>(path: P) => FieldState<FieldPathValue<TValues, P>>;
    readonly setValue: <P extends FieldPath<TValues>>(path: P, value: FieldPathInput<TValues, P>) => void;
    readonly touch: (path: FieldPath<TValues>) => void;
    readonly append: <P extends FieldPath<TValues>>(path: P & ArrayEditPath<TValues, P>, value: ArrayItem<FieldPathInput<TValues, P>>) => void;
    readonly remove: <P extends FieldPath<TValues>>(path: P & ArrayEditPath<TValues, P>, index: number) => void;
    readonly move: <P extends FieldPath<TValues>>(path: P & ArrayEditPath<TValues, P>, from: number, to: number) => void;
    readonly reset: (values?: TValues) => void;
    readonly submit: () => Promise<SubmissionResult<TSuccess, TError>>;
    /** A lazy waiter on the session-owned execution; interrupting it does not cancel shared work. */
    readonly submitEffect: () => Effect.Effect<SubmissionResult<TSuccess, TError>>;
    readonly cancel: () => void;
    readonly dispose: () => void;
    readonly updateOptions: (options: SessionOptions<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>) => void;
}
export declare function createFormSession<TValues extends object, TOutput = TValues, TSuccess = void, TError = unknown, TServices = never, TSchemaServices = never>(initialOptions: SessionOptions<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>): FormSession<TValues, TOutput, TSuccess, TError, TServices, TSchemaServices>;
export {};
