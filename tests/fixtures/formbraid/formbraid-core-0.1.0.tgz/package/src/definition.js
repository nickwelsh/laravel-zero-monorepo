import { pathSegments } from './paths.js';
// oxlint-disable-next-line typescript/no-unnecessary-type-parameters -- The outer constraint permits explicitly chosen services while the inner schema generic infers them.
export function defineForm() {
    return (definition) => {
        const claimed = new Set();
        for (const field of Object.values(definition.fields)) {
            pathSegments(field.name.replaceAll('.*', '.0'));
        }
        for (const [name, group] of Object.entries(definition.groups)) {
            for (const path of Object.values(group.fields)) {
                if (!Object.values(definition.fields).some((field) => field.name === path)) {
                    throw new Error(`Group ${name} references unknown field ${path}.`);
                }
                if (claimed.has(path)) {
                    throw new Error(`Field ${path} belongs to more than one group.`);
                }
                claimed.add(path);
            }
        }
        return definition;
    };
}
export function bindForm(definition, submission) {
    return { version: 1, definition, submission };
}
export function routeUrl(uri, parameters) {
    const used = new Set();
    const url = uri.replaceAll(/\{(?<name>\w+)(?<optional>\?)?\}/gu, (_, name, optional) => {
        used.add(name);
        const value = parameters[name];
        if (value === undefined) {
            if (optional !== undefined) {
                return '';
            }
            throw new Error(`Missing route parameter: ${name}`);
        }
        return encodeURIComponent(String(value));
    });
    for (const name of Object.keys(parameters)) {
        if (!used.has(name)) {
            throw new Error(`Unknown route parameter: ${name}`);
        }
    }
    return `/${url.replaceAll(/^\/+|\/+$/gu, '')}`;
}
