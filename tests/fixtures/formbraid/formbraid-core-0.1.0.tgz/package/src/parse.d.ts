import { Effect, Schema } from 'effect';
import type { HttpOperation, Extraction, JsonValue, FormDescriptorData } from './contracts.js';
export declare const JsonValueSchema: Schema.Codec<Schema.Json, Schema.Json, never, never>;
export declare const JsonObjectSchema: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
export declare const RequiredConditionSchema: Schema.Struct<{
    readonly field: Schema.String;
    readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
}>;
export declare const ConstraintsSchema: Schema.Struct<{
    readonly required: Schema.optionalKey<Schema.Boolean>;
    readonly requiredWhen: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly field: Schema.String;
        readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
    }>>>;
    readonly minLength: Schema.optionalKey<Schema.Finite>;
    readonly maxLength: Schema.optionalKey<Schema.Finite>;
    readonly min: Schema.optionalKey<Schema.Finite>;
    readonly max: Schema.optionalKey<Schema.Finite>;
    readonly minItems: Schema.optionalKey<Schema.Finite>;
    readonly maxItems: Schema.optionalKey<Schema.Finite>;
    readonly options: Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Finite]>>>;
    readonly format: Schema.optionalKey<Schema.Literals<readonly ["email", "url", "date"]>>;
}>;
export declare const FieldDefinitionSchema: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literals<readonly ["string", "integer", "number", "boolean", "date", "enum", "file", "array", "object"]>;
    readonly component: Schema.String;
    readonly label: Schema.String;
    readonly helpText: Schema.optionalKey<Schema.String>;
    readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly constraints: Schema.Struct<{
        readonly required: Schema.optionalKey<Schema.Boolean>;
        readonly requiredWhen: Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly field: Schema.String;
            readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
        }>>>;
        readonly minLength: Schema.optionalKey<Schema.Finite>;
        readonly maxLength: Schema.optionalKey<Schema.Finite>;
        readonly min: Schema.optionalKey<Schema.Finite>;
        readonly max: Schema.optionalKey<Schema.Finite>;
        readonly minItems: Schema.optionalKey<Schema.Finite>;
        readonly maxItems: Schema.optionalKey<Schema.Finite>;
        readonly options: Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Finite]>>>;
        readonly format: Schema.optionalKey<Schema.Literals<readonly ["email", "url", "date"]>>;
    }>;
    readonly nullable: Schema.Boolean;
    readonly serverRules: Schema.$Array<Schema.String>;
}>;
export declare const GroupDefinitionSchema: Schema.Struct<{
    readonly component: Schema.String;
    readonly label: Schema.optionalKey<Schema.String>;
    readonly helpText: Schema.optionalKey<Schema.String>;
    readonly fields: Schema.$Record<Schema.String, Schema.String>;
    readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
}>;
export declare const FormMetadataSchema: Schema.Struct<{
    readonly id: Schema.String;
    readonly defaultValues: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly fields: Schema.$Record<Schema.String, Schema.Struct<{
        readonly name: Schema.String;
        readonly type: Schema.Literals<readonly ["string", "integer", "number", "boolean", "date", "enum", "file", "array", "object"]>;
        readonly component: Schema.String;
        readonly label: Schema.String;
        readonly helpText: Schema.optionalKey<Schema.String>;
        readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        readonly constraints: Schema.Struct<{
            readonly required: Schema.optionalKey<Schema.Boolean>;
            readonly requiredWhen: Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly field: Schema.String;
                readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
                readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
            }>>>;
            readonly minLength: Schema.optionalKey<Schema.Finite>;
            readonly maxLength: Schema.optionalKey<Schema.Finite>;
            readonly min: Schema.optionalKey<Schema.Finite>;
            readonly max: Schema.optionalKey<Schema.Finite>;
            readonly minItems: Schema.optionalKey<Schema.Finite>;
            readonly maxItems: Schema.optionalKey<Schema.Finite>;
            readonly options: Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Finite]>>>;
            readonly format: Schema.optionalKey<Schema.Literals<readonly ["email", "url", "date"]>>;
        }>;
        readonly nullable: Schema.Boolean;
        readonly serverRules: Schema.$Array<Schema.String>;
    }>>;
    readonly groups: Schema.$Record<Schema.String, Schema.Struct<{
        readonly component: Schema.String;
        readonly label: Schema.optionalKey<Schema.String>;
        readonly helpText: Schema.optionalKey<Schema.String>;
        readonly fields: Schema.$Record<Schema.String, Schema.String>;
        readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>>;
}>;
export declare const ExtractionSchema: Schema.Struct<{
    readonly version: Schema.Literal<1>;
    readonly forms: Schema.$Array<Schema.Struct<{
        readonly id: Schema.String;
        readonly defaultValues: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        readonly fields: Schema.$Record<Schema.String, Schema.Struct<{
            readonly name: Schema.String;
            readonly type: Schema.Literals<readonly ["string", "integer", "number", "boolean", "date", "enum", "file", "array", "object"]>;
            readonly component: Schema.String;
            readonly label: Schema.String;
            readonly helpText: Schema.optionalKey<Schema.String>;
            readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            readonly constraints: Schema.Struct<{
                readonly required: Schema.optionalKey<Schema.Boolean>;
                readonly requiredWhen: Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly field: Schema.String;
                    readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
                    readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
                }>>>;
                readonly minLength: Schema.optionalKey<Schema.Finite>;
                readonly maxLength: Schema.optionalKey<Schema.Finite>;
                readonly min: Schema.optionalKey<Schema.Finite>;
                readonly max: Schema.optionalKey<Schema.Finite>;
                readonly minItems: Schema.optionalKey<Schema.Finite>;
                readonly maxItems: Schema.optionalKey<Schema.Finite>;
                readonly options: Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Finite]>>>;
                readonly format: Schema.optionalKey<Schema.Literals<readonly ["email", "url", "date"]>>;
            }>;
            readonly nullable: Schema.Boolean;
            readonly serverRules: Schema.$Array<Schema.String>;
        }>>;
        readonly groups: Schema.$Record<Schema.String, Schema.Struct<{
            readonly component: Schema.String;
            readonly label: Schema.optionalKey<Schema.String>;
            readonly helpText: Schema.optionalKey<Schema.String>;
            readonly fields: Schema.$Record<Schema.String, Schema.String>;
            readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        }>>;
    }>>;
    readonly diagnostics: Schema.$Array<Schema.String>;
}>;
export declare const SubmissionTargetSchema: Schema.Struct<{
    readonly url: Schema.String;
    readonly method: Schema.Literals<readonly ["get", "post", "put", "patch", "delete"]>;
}>;
export declare const SubmissionBindingSchema: Schema.Struct<{
    readonly driver: Schema.String;
    readonly binding: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>;
/** Only the serializable named-driver branch crosses a JSON boundary. */
export declare const FormDescriptorSchema: Schema.Struct<{
    readonly version: Schema.Literal<1>;
    readonly definition: Schema.Struct<{
        readonly id: Schema.String;
        readonly defaultValues: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        readonly fields: Schema.$Record<Schema.String, Schema.Struct<{
            readonly name: Schema.String;
            readonly type: Schema.Literals<readonly ["string", "integer", "number", "boolean", "date", "enum", "file", "array", "object"]>;
            readonly component: Schema.String;
            readonly label: Schema.String;
            readonly helpText: Schema.optionalKey<Schema.String>;
            readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            readonly constraints: Schema.Struct<{
                readonly required: Schema.optionalKey<Schema.Boolean>;
                readonly requiredWhen: Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly field: Schema.String;
                    readonly values: Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
                    readonly operator: Schema.Literals<readonly ["equals", "notEquals", "present", "absent"]>;
                }>>>;
                readonly minLength: Schema.optionalKey<Schema.Finite>;
                readonly maxLength: Schema.optionalKey<Schema.Finite>;
                readonly min: Schema.optionalKey<Schema.Finite>;
                readonly max: Schema.optionalKey<Schema.Finite>;
                readonly minItems: Schema.optionalKey<Schema.Finite>;
                readonly maxItems: Schema.optionalKey<Schema.Finite>;
                readonly options: Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Finite]>>>;
                readonly format: Schema.optionalKey<Schema.Literals<readonly ["email", "url", "date"]>>;
            }>;
            readonly nullable: Schema.Boolean;
            readonly serverRules: Schema.$Array<Schema.String>;
        }>>;
        readonly groups: Schema.$Record<Schema.String, Schema.Struct<{
            readonly component: Schema.String;
            readonly label: Schema.optionalKey<Schema.String>;
            readonly helpText: Schema.optionalKey<Schema.String>;
            readonly fields: Schema.$Record<Schema.String, Schema.String>;
            readonly props: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        }>>;
    }>;
    readonly defaultValues: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>;
    readonly submission: Schema.Struct<{
        readonly driver: Schema.String;
        readonly binding: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    }>;
}>;
export declare const HttpOperationSchema: Schema.Codec<HttpOperation>;
export declare const OperationParameterSchema: Schema.Struct<{
    readonly name: Schema.String;
    readonly optional: Schema.optionalKey<Schema.Boolean>;
}>;
export declare function operationSchema<S extends Schema.Constraint>(binding: S): Schema.Struct<{
    readonly name: Schema.String;
    readonly schema: Schema.String;
    readonly parameters: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly optional: Schema.optionalKey<Schema.Boolean>;
    }>>;
    readonly binding: S;
}>;
export declare const isRecord: <I>(input: I) => input is I & {
    readonly [x: string]: unknown;
};
export declare const isJsonValue: <I>(input: I) => input is I & Schema.Json;
/** Native decoders retain structured schema failures for Effect workflows. */
export declare const parseExtractionEffect: (json: string) => Effect.Effect<Extraction, Schema.SchemaError>;
export declare const parseJsonValueEffect: (json: string) => Effect.Effect<JsonValue, Schema.SchemaError>;
export declare const parseFormDescriptorEffect: (json: string) => Effect.Effect<FormDescriptorData, Schema.SchemaError>;
export declare function parseFormDescriptor(json: string): FormDescriptorData;
/** Synchronous compiler/API boundaries execute the same native decoder. */
export declare function parseExtraction(json: string): Extraction;
export declare function parseJsonValue(json: string): JsonValue;
