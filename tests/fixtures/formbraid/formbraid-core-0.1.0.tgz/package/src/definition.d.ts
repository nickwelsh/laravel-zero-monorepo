import type { FieldDefinition, FormDefinition, GroupDefinition, SubmissionBinding, BoundForm } from './contracts.js';
export declare function defineForm<TValues extends object, TOutput = TValues, TServices = unknown>(): <const TFields extends Readonly<Record<string, FieldDefinition>>, const TGroups extends Readonly<Record<string, GroupDefinition>>, TSchemaServices extends TServices = never>(definition: FormDefinition<TValues, TFields, TGroups, TOutput, TSchemaServices>) => FormDefinition<TValues, TFields, TGroups, TOutput, TSchemaServices>;
export declare function bindForm<TDefinition extends FormDefinition<object, Readonly<Record<string, FieldDefinition>>, Readonly<Record<string, GroupDefinition>>, unknown, unknown>>(definition: TDefinition, submission: SubmissionBinding): BoundForm<TDefinition> & {
    readonly version: 1;
};
export declare function routeUrl(uri: string, parameters: Readonly<Record<string, string | number>>): string;
