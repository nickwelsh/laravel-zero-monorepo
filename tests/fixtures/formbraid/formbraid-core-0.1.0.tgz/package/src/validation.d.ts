import { Schema } from 'effect';
import type { Constraints, FieldDefinition } from './contracts.js';
export declare function resolveConstraints(constraints: Constraints, values: unknown): Constraints;
/** Compile Laravel metadata into native Effect schemas; cross-field rules own the root refinement. */
export declare function definitionSchema<TValues extends object>(definition: {
    readonly fields: Readonly<Record<string, FieldDefinition>>;
    readonly defaultValues: TValues;
}): Schema.Codec<TValues, TValues>;
