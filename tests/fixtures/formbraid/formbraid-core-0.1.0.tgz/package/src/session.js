/* oxlint-disable typescript/no-unsafe-type-assertion -- Immutable path updates preserve the public generic types after runtime container/path checks. */
import { Cause, Deferred, Effect, Equal, Exit, Fiber, Ref, Scope, Schema as EffectSchema, SchemaAST, SchemaIssue, Result, } from 'effect';
import { AtomRef } from 'effect/reactivity';
import { definitionArrayAt, getValue, isPathSegment, normalizePath, pathSegments } from './paths.js';
import { definitionSchema } from './validation.js';
function reportObserverError(error) {
    if (typeof reportError === 'function') {
        reportError(error);
    }
}
function notifyResult(observer, result) {
    try {
        observer?.(result);
    }
    catch (error) {
        reportObserverError(error);
    }
}
const emptyErrors = Object.freeze([]);
function plain(value) {
    return (typeof value === 'object' &&
        value !== null &&
        (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null));
}
/** Clone and freeze owned containers; files and other platform objects stay atomic. */
function own(value) {
    if (Array.isArray(value)) {
        return Object.freeze(value.map((item) => own(item)));
    }
    if (plain(value)) {
        return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, item]) => [key, own(item)])));
    }
    return value;
}
function ownValidationErrors(errors) {
    return Object.freeze(Object.fromEntries(Object.entries(errors).map(([path, messages]) => [
        path,
        typeof messages === 'string' ? messages : Object.freeze([...messages]),
    ])));
}
/** Own the execution envelope and validation messages; domain payloads remain opaque. */
function ownExecution(execution) {
    const { status } = execution;
    switch (status) {
        case 'success': {
            return Object.freeze('value' in execution ? { status, value: execution.value } : { status });
        }
        case 'invalid': {
            return Object.freeze({ status, errors: ownValidationErrors(execution.errors) });
        }
        case 'failure': {
            return Object.freeze({ status, error: execution.error });
        }
        case 'defect': {
            return Object.freeze({ status, error: execution.error });
        }
        case 'idle':
        case 'validating':
        case 'submitting':
        case 'cancelled': {
            return Object.freeze({ status });
        }
        default: {
            throw new TypeError('Invalid form execution status.');
        }
    }
}
function equal(a, b) {
    if (Object.is(a, b)) {
        return true;
    }
    if (Array.isArray(a) && Array.isArray(b)) {
        if (a.length !== b.length) {
            return false;
        }
        for (let i = 0; i < a.length; i += 1) {
            if (Object.hasOwn(a, i) !== Object.hasOwn(b, i) || !equal(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    if (plain(a) && plain(b)) {
        const keys = Object.keys(a);
        return (keys.length === Object.keys(b).length && keys.every((key) => Object.hasOwn(b, key) && equal(a[key], b[key])));
    }
    return false;
}
// oxlint-disable-next-line eslint/max-params -- Recursive replacement carries the container resolver and its current prefix separately from the value path.
function replace(values, segments, value, isArray, prefix = []) {
    const [head, ...tail] = segments;
    if (head === undefined) {
        // edit owns the replacement before traversing or committing this tree.
        return value;
    }
    if (values === null || values === undefined) {
        // Optional and nullable containers have no existing data to preserve.
        if (isArray(prefix)) {
            if (head !== '0') {
                throw new Error(`Invalid array index: ${head}`);
            }
            return Object.freeze([replace(undefined, tail, value, isArray, [...prefix, head])]);
        }
        return Object.freeze({ [head]: replace(undefined, tail, value, isArray, [...prefix, head]) });
    }
    if (Array.isArray(values)) {
        if (!/^\d+$/u.test(head) || Number(head) >= values.length) {
            throw new Error(`Invalid array index: ${head}`);
        }
        // oxlint-disable-next-line unicorn/prefer-spread -- slice preserves untouched sparse slots; spread fills them with undefined.
        const copy = values.slice();
        copy[Number(head)] = replace(values[Number(head)], tail, value, isArray, [...prefix, head]);
        return Object.freeze(copy);
    }
    if (!plain(values)) {
        throw new Error(`Cannot edit atomic field: ${segments.join('.')}`);
    }
    return Object.freeze({
        ...values,
        [head]: replace(Object.hasOwn(values, head) ? values[head] : undefined, tail, value, isArray, [
            ...prefix,
            head,
        ]),
    });
}
function assertIndex(items, index) {
    if (!Number.isInteger(index) || index < 0 || index >= items.length) {
        throw new Error(`Invalid array index: ${index}`);
    }
}
function overlaps(a, b) {
    return a === '' || b === '' || a === b || a.startsWith(`${b}.`) || b.startsWith(`${a}.`);
}
const formatIssue = SchemaIssue.makeFormatterDefault();
function issueErrors(issue) {
    const errors = {};
    const add = (path, message) => {
        const key = path.length === 0 || path.some((part) => typeof part === 'symbol' || !isPathSegment(String(part)))
            ? ''
            : path.join('.');
        const messages = Object.hasOwn(errors, key) ? errors[key] : undefined;
        errors[key] = [...(messages ?? []), message];
    };
    const visit = (node, path) => {
        // oxlint-disable-next-line eslint/no-underscore-dangle -- Effect native issues use this discriminator.
        switch (node._tag) {
            case 'Pointer': {
                visit(node.issue, [...path, ...node.path]);
                break;
            }
            case 'Composite': {
                for (const child of node.issues) {
                    visit(child, path);
                }
                break;
            }
            case 'Encoding': {
                visit(node.issue, path);
                break;
            }
            case 'Filter': {
                const message = SchemaIssue.defaultCheckHook(node);
                if (message === undefined) {
                    visit(node.issue, path);
                }
                else {
                    add(path, message);
                }
                break;
            }
            case 'AnyOf': {
                if (node.issues.length === 0) {
                    add(path, formatIssue(node));
                }
                else {
                    for (const child of node.issues) {
                        visit(child, path);
                    }
                }
                break;
            }
            case 'Forbidden':
            case 'InvalidType':
            case 'InvalidValue':
            case 'MissingKey':
            case 'OneOf':
            case 'UnexpectedKey': {
                add(path, formatIssue(node));
                break;
            }
            default: {
                throw new TypeError('Unsupported native validation issue.');
            }
        }
    };
    visit(issue, []);
    return errors;
}
function settleSubmission(submission, result) {
    Deferred.doneUnsafe(submission.result, Effect.succeed(result));
}
/** Synchronous owner boundaries close native scopes immediately and run every finalizer. */
function closeScope(scope) {
    const close = Scope.closeUnsafe(scope, Exit.void);
    if (close !== undefined) {
        Effect.runFork(Effect.uninterruptible(close));
    }
}
const generatedSchemas = new WeakMap();
function generatedSchema(definition) {
    const cached = generatedSchemas.get(definition);
    if (cached !== undefined) {
        return cached;
    }
    const schema = definitionSchema(definition);
    generatedSchemas.set(definition, schema);
    return schema;
}
function expandSchemaContainers(node, seen = new Set()) {
    if (seen.has(node)) {
        return [];
    }
    seen.add(node);
    if (SchemaAST.isUnion(node)) {
        return node.types.flatMap((type) => expandSchemaContainers(type, new Set(seen)));
    }
    if (SchemaAST.isSuspend(node)) {
        return expandSchemaContainers(node.thunk(), seen);
    }
    return [node];
}
const indexSignatureMatchers = new WeakMap();
function matchesIndexSignature(entry, key) {
    let matches = indexSignatureMatchers.get(entry);
    if (matches === undefined) {
        // A one-key record probe delegates numeric, template and refined key matching to Effect's parser.
        const ast = new SchemaAST.Objects([], [new SchemaAST.IndexSignature(entry.parameter, SchemaAST.unknown)]);
        const schema = EffectSchema.make(ast);
        const decode = EffectSchema.decodeUnknownResult(schema, { onExcessProperty: 'error' });
        matches = (segment) => Result.isSuccess(decode({ [segment]: undefined }));
        indexSignatureMatchers.set(entry, matches);
    }
    return matches(key);
}
function schemaContainer(ast, path, values) {
    let nodes = expandSchemaContainers(SchemaAST.toEncoded(ast));
    let value = values;
    for (const segment of path) {
        const containerValue = value;
        nodes = nodes.flatMap((node) => {
            if (SchemaAST.isArrays(node) && /^\d+$/u.test(segment)) {
                const index = Number(segment);
                const element = node.elements[index];
                if (element !== undefined) {
                    return expandSchemaContainers(element);
                }
                if (!Array.isArray(containerValue)) {
                    // Missing tuples have no tail position yet; preserve every applicable rest alternative.
                    return node.rest.flatMap((child) => expandSchemaContainers(child));
                }
                const tailLength = Math.max(0, node.rest.length - 1);
                const tailStart = Math.max(node.elements.length, containerValue.length - tailLength);
                const child = tailLength > 0 && index >= tailStart && index < containerValue.length
                    ? node.rest[index - tailStart + 1]
                    : node.rest[0];
                return child === undefined ? [] : expandSchemaContainers(child);
            }
            if (SchemaAST.isObjects(node)) {
                const property = node.propertySignatures.find((entry) => String(entry.name) === segment);
                return property === undefined
                    ? node.indexSignatures.flatMap((entry) => matchesIndexSignature(entry, segment) ? expandSchemaContainers(entry.type) : [])
                    : expandSchemaContainers(property.type);
            }
            return [];
        });
        value = getValue(value, segment);
    }
    const arrays = nodes.some((node) => SchemaAST.isArrays(node));
    const objects = nodes.some((node) => SchemaAST.isObjects(node));
    if (arrays === objects) {
        return undefined;
    }
    return arrays ? 'array' : 'object';
}
export function createFormSession(initialOptions) {
    const defaults = own(initialOptions.defaultValues ?? initialOptions.definition.defaultValues);
    const initialState = Object.freeze({
        values: defaults,
        baseline: defaults,
        fields: Object.freeze({}),
        errors: Object.freeze({}),
        execution: Object.freeze({ status: 'idle' }),
        progress: undefined,
        isDirty: false,
        submitCount: 0,
    });
    const state = AtomRef.make(Equal.byReferenceUnsafe(initialState));
    const scope = Scope.makeUnsafe('parallel');
    const control = Ref.makeUnsafe({ options: initialOptions, disposed: false, active: undefined, revision: 0, revisions: new Map() });
    const owner = () => Ref.getUnsafe(control);
    const updateOwner = (patch) => {
        Effect.runSync(Ref.update(control, (previous) => ({ ...previous, ...patch })));
    };
    const publish = (patch) => {
        const previous = state.value;
        // State snapshots compare by identity; domain payloads and platform objects are opaque to reactivity.
        const snapshot = Object.freeze({
            ...previous,
            ...patch,
            fields: patch.fields === undefined ? previous.fields : own(patch.fields),
            errors: patch.errors === undefined ? previous.errors : own(patch.errors),
            execution: patch.execution === undefined ? previous.execution : ownExecution(patch.execution),
        });
        state.set(Equal.byReferenceUnsafe(snapshot));
    };
    const assertLive = () => {
        if (owner().disposed) {
            throw new Error('Form session is disposed.');
        }
    };
    const isAbsentArray = (prefix) => {
        const { options } = owner();
        const schema = options.schema ?? options.definition.schema;
        if (schema !== undefined) {
            const kind = schemaContainer(schema.ast, prefix, state.value.values);
            if (kind !== undefined) {
                return kind === 'array';
            }
        }
        if (prefix.length > 0 && Array.isArray(getValue(state.value.baseline, prefix.join('.')))) {
            return true;
        }
        return definitionArrayAt(options.definition, prefix);
    };
    const canonicalPath = (path) => normalizePath(path, state.value.values, isAbsentArray);
    const edit = (path, value, fields) => {
        assertLive();
        pathSegments(path);
        const before = state.value;
        const prepared = own(value);
        if (owner().disposed || state.value !== before) {
            return;
        }
        const key = canonicalPath(path);
        // oxlint-disable-next-line typescript/no-unnecessary-condition -- Schema/metadata accessors can dispose or replace state during path preparation.
        if (owner().disposed || state.value !== before) {
            return;
        }
        const values = replace(before.values, pathSegments(key), prepared, isAbsentArray);
        // oxlint-disable-next-line typescript/no-unnecessary-condition -- Absent-container inference can invoke application schema/metadata accessors while traversing.
        if (owner().disposed || state.value !== before) {
            return;
        }
        if (fields === undefined && equal(values, state.value.values)) {
            return;
        }
        const revision = owner().revision + 1;
        const revisions = new Map([...owner().revisions, [key, revision]]);
        updateOwner({ revision, revisions });
        const errors = Object.fromEntries(Object.entries(state.value.errors).filter(([name]) => !overlaps(key, name)));
        const patch = { values, errors, isDirty: !equal(values, state.value.baseline) };
        if (fields !== undefined) {
            Object.assign(patch, { fields });
        }
        publish(patch);
    };
    const array = (path) => {
        assertLive();
        const values = getValue(state.value.values, canonicalPath(path));
        if (values === null || values === undefined) {
            return [];
        }
        if (!Array.isArray(values)) {
            throw new TypeError(`Field is not an array: ${path}`);
        }
        // oxlint-disable-next-line unicorn/prefer-spread -- Structural edits must preserve sparse slots before remapping indexes.
        return values.slice();
    };
    const structuralEdit = (path, items, order) => {
        const key = canonicalPath(path);
        const fields = {};
        for (const [name, meta] of Object.entries(state.value.fields)) {
            if (name.startsWith(`${key}.`)) {
                const [row, ...rest] = name.slice(key.length + 1).split('.');
                const next = order.indexOf(Number(row));
                if (next !== -1) {
                    fields[`${key}.${next}${rest.length === 0 ? '' : `.${rest.join('.')}`}`] = meta;
                }
            }
            else {
                fields[name] = meta;
            }
        }
        edit(path, items, fields);
    };
    const detach = () => Effect.runSync(Ref.modify(control, (previous) => [previous.active, { ...previous, active: undefined }]));
    const interrupt = (current) => {
        settleSubmission(current, { status: 'cancelled' });
        current.controller.abort();
        closeScope(current.scope);
        if (!owner().disposed) {
            notifyResult(Ref.getUnsafe(current.onResult), { status: 'cancelled' });
        }
    };
    const cancel = () => {
        const current = detach();
        if (current !== undefined) {
            if (!owner().disposed) {
                publish({ execution: { status: 'cancelled' }, progress: undefined });
            }
            interrupt(current);
        }
    };
    const startSubmission = () => {
        assertLive();
        const existing = owner().active;
        if (existing !== undefined) {
            return existing;
        }
        const submitted = state.value.values;
        const submittedRevision = owner().revision;
        const capturedOptions = owner().options;
        const controller = new AbortController();
        const deferredResult = Deferred.makeUnsafe();
        const executionScope = Scope.forkUnsafe(scope);
        const current = {
            controller,
            scope: executionScope,
            result: deferredResult,
            promise: Effect.runPromise(Deferred.await(deferredResult)),
            // oxlint-disable-next-line unicorn/no-useless-undefined -- Native Ref requires its initial callback value.
            onResult: Ref.makeUnsafe(undefined),
        };
        updateOwner({ active: current });
        Effect.runSync(Scope.addFinalizer(executionScope, Effect.sync(() => controller.abort())));
        const live = () => !owner().disposed && owner().active === current && !controller.signal.aborted;
        const unchanged = (path) => ![...owner().revisions].some(([changed, at]) => at > submittedRevision && overlaps(changed, path));
        const filterErrors = (errors) => {
            const filtered = {};
            for (const [path, messages] of Object.entries(errors)) {
                const key = path === '' ? '' : canonicalPath(path);
                if (unchanged(key)) {
                    filtered[key] = typeof messages === 'string' ? [messages] : [...messages];
                }
            }
            return filtered;
        };
        const complete = (incoming) => {
            if (!live()) {
                return;
            }
            // oxlint-disable-next-line eslint/init-declarations -- Both preparation branches install a complete result before publication.
            let result;
            let errors = {};
            try {
                // Prepare owned messages before detaching so malformed driver results cannot strand waiters.
                result = ownExecution(incoming);
                if (result.status === 'invalid') {
                    errors = filterErrors(result.errors);
                }
            }
            catch (error) {
                result = { status: 'defect', error };
            }
            // Result accessors can synchronously cancel/reset and start a successor while being normalized.
            if (!live()) {
                return;
            }
            const patch = { execution: result, progress: undefined };
            if (result.status === 'success') {
                Object.assign(patch, {
                    baseline: submitted,
                    errors: {},
                    isDirty: !equal(state.value.values, submitted),
                });
            }
            if (result.status === 'invalid') {
                Object.assign(patch, { errors });
            }
            if (result.status === 'failure' || result.status === 'defect') {
                Object.assign(patch, { errors: { '': ['Unable to submit the form. Please try again.'] } });
            }
            updateOwner({ active: undefined });
            // Resolve even if a callback or observer fails; application code cannot strand the task.
            publish(patch);
            settleSubmission(current, result);
            notifyResult(Ref.getUnsafe(current.onResult), result);
            closeScope(current.scope);
        };
        // Install the shared task before reading application callbacks so acquisition can safely reenter.
        try {
            const observer = capturedOptions.onResult;
            if (live()) {
                Effect.runSync(Ref.set(current.onResult, observer));
            }
        }
        catch (error) {
            complete({ status: 'defect', error });
            return current;
        }
        if (!live()) {
            return current;
        }
        publish({
            execution: { status: 'validating' },
            errors: {},
            progress: undefined,
            submitCount: state.value.submitCount + 1,
        });
        const program = Effect.gen(function* program() {
            if (!live()) {
                return { status: 'cancelled' };
            }
            const schema = yield* Effect.sync(() => capturedOptions.schema ??
                capturedOptions.definition.schema ??
                generatedSchema(capturedOptions.definition));
            if (!live()) {
                return { status: 'cancelled' };
            }
            const validated = yield* Effect.result(EffectSchema.decodeUnknownEffect(schema, { errors: 'all' })(submitted));
            if (!live()) {
                return { status: 'cancelled' };
            }
            if (Result.isFailure(validated)) {
                return { status: 'invalid', errors: issueErrors(validated.failure.issue) };
            }
            yield* Effect.sync(() => publish({ execution: { status: 'submitting' } }));
            if (!live()) {
                return { status: 'cancelled' };
            }
            const context = {
                signal: controller.signal,
                onProgress: (progress) => {
                    if (live()) {
                        const { percentage } = progress;
                        const normalized = Object.freeze({
                            loaded: progress.loaded,
                            total: progress.total,
                            ...(percentage === undefined ? {} : { percentage }),
                        });
                        if (live()) {
                            publish({ progress: normalized });
                        }
                    }
                },
            };
            const execute = capturedOptions.operation;
            if (execute !== undefined) {
                const operation = Effect.suspend(() => execute(validated.success, context));
                return yield* Effect.match(operation, {
                    onSuccess: (value) => ({ status: 'success', value }),
                    onFailure: (error) => ({ status: 'failure', error }),
                });
            }
            const { submit } = capturedOptions;
            if (submit !== undefined) {
                return yield* Effect.promise(async () => await submit(validated.success, context));
            }
            const { driver } = capturedOptions;
            if (driver !== undefined) {
                const data = validated.success;
                if (typeof data !== 'object' || data === null) {
                    return yield* Effect.die(new Error('Submission drivers require an object schema output.'));
                }
                return yield* Effect.suspend(() => driver.submit({
                    data,
                    binding: capturedOptions.binding ?? null,
                    ...context,
                }));
            }
            return yield* Effect.die(new Error('No form operation or submission driver configured.'));
        });
        // The session scope owns one native execution fiber. Service runners are boundary adapters only.
        try {
            // A service-requiring SessionOptions must provide run; only service-free calls use the fallback.
            const providedRun = capturedOptions.run;
            if (live()) {
                let workflow = Effect.scoped(program);
                if (providedRun !== undefined) {
                    // Runner acquisition is synchronous: a thrown boundary failure is already terminal on return.
                    const running = providedRun(Effect.scoped(program), { signal: controller.signal });
                    workflow = Effect.promise(async () => await running);
                }
                // Yield completion to let all synchronous callers acquire this execution's Deferred.
                const fiber = Fiber.runIn(Effect.runFork(Effect.tap(workflow, () => Effect.yieldNow)), executionScope);
                fiber.addObserver((exit) => {
                    complete(Exit.isSuccess(exit) ? exit.value : { status: 'defect', error: Cause.squash(exit.cause) });
                });
            }
        }
        catch (error) {
            complete({ status: 'defect', error });
        }
        return current;
    };
    const session = {
        getSnapshot: () => state.value,
        resolvePath: canonicalPath,
        subscribe: (listener) => {
            assertLive();
            const subscriptionScope = Scope.forkUnsafe(scope);
            const unsubscribe = state.subscribe(() => {
                if (!owner().disposed) {
                    try {
                        listener();
                    }
                    catch (error) {
                        reportObserverError(error);
                    }
                }
            });
            Effect.runSync(Scope.addFinalizer(subscriptionScope, Effect.sync(unsubscribe)));
            return () => closeScope(subscriptionScope);
        },
        getField: (path) => {
            const key = canonicalPath(path);
            return {
                value: getValue(state.value.values, key),
                touched: state.value.fields[key]?.touched ?? false,
                dirty: !equal(getValue(state.value.values, path), getValue(state.value.baseline, path)),
                errors: Object.hasOwn(state.value.errors, key) ? (state.value.errors[key] ?? emptyErrors) : emptyErrors,
            };
        },
        setValue: (path, value) => edit(path, value),
        touch: (path) => {
            assertLive();
            const key = canonicalPath(path);
            if (state.value.fields[key]?.touched !== true) {
                publish({ fields: Object.freeze({ ...state.value.fields, [key]: Object.freeze({ touched: true }) }) });
            }
        },
        append: (path, value) => {
            const items = array(path);
            const order = Array.from({ length: items.length }, (_, i) => i);
            items.push(value);
            order.push(-1);
            structuralEdit(path, items, order);
        },
        remove: (path, i) => {
            const items = array(path);
            assertIndex(items, i);
            const order = Array.from({ length: items.length }, (_, at) => at);
            items.splice(i, 1);
            order.splice(i, 1);
            structuralEdit(path, items, order);
        },
        move: (path, from, to) => {
            const items = array(path);
            assertIndex(items, from);
            assertIndex(items, to);
            if (from === to) {
                return;
            }
            const order = Array.from({ length: items.length }, (_, at) => at);
            const [at] = order.splice(from, 1);
            if (at === undefined) {
                throw new Error(`Invalid array index: ${from}`);
            }
            order.splice(to, 0, at);
            const present = Object.hasOwn(items, from);
            const [item] = items.splice(from, 1);
            items.splice(to, 0, item);
            if (!present) {
                Reflect.deleteProperty(items, to);
            }
            structuralEdit(path, items, order);
        },
        reset: (values) => {
            assertLive();
            const before = state.value;
            const baseline = own(values ?? state.value.baseline);
            if (owner().disposed || state.value !== before) {
                return;
            }
            const interrupted = detach();
            updateOwner({ revisions: new Map() });
            publish({
                values: baseline,
                baseline,
                fields: {},
                errors: {},
                execution: { status: 'idle' },
                progress: undefined,
                isDirty: false,
                submitCount: 0,
            });
            if (interrupted !== undefined) {
                interrupt(interrupted);
            }
        },
        cancel,
        dispose: () => {
            if (owner().disposed) {
                return;
            }
            updateOwner({ disposed: true });
            const interrupted = detach();
            if (interrupted !== undefined) {
                interrupt(interrupted);
            }
            closeScope(scope);
        },
        updateOptions: (next) => {
            assertLive();
            updateOwner({ options: next });
        },
        // Promise identity is part of duplicate-submit coalescing.
        // oxlint-disable-next-line typescript/promise-function-async
        submit: () => startSubmission().promise,
        submitEffect: () => Effect.flatMap(Effect.sync(startSubmission), (submission) => Deferred.await(submission.result)),
    };
    return session;
}
