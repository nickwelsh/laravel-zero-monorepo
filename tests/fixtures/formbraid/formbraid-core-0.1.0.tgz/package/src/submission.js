import { Effect } from 'effect';
/** Adapt a typed binding executor to the portable runtime boundary. */
export function defineSubmissionDriver(options) {
    return {
        submit: (context) => {
            if (!options.accepts(context.binding)) {
                return Effect.succeed({ status: 'failure', error: new Error('Unsupported submission binding.') });
            }
            return options.submit({ ...context, binding: context.binding });
        },
    };
}
