/* oxlint-disable eslint/new-cap -- Effect uses capitalized functional Schema constructors. */
import { Effect, Schema } from 'effect';
export const JsonValueSchema = Schema.Json;
export const JsonObjectSchema = Schema.JsonObject;
const OptionSchema = Schema.Union([Schema.String, Schema.Finite]);
export const RequiredConditionSchema = Schema.Struct({
    field: Schema.String,
    values: Schema.Array(JsonValueSchema),
    operator: Schema.Literals(['equals', 'notEquals', 'present', 'absent']),
});
export const ConstraintsSchema = Schema.Struct({
    required: Schema.optionalKey(Schema.Boolean),
    requiredWhen: Schema.optionalKey(Schema.Array(RequiredConditionSchema)),
    minLength: Schema.optionalKey(Schema.Finite),
    maxLength: Schema.optionalKey(Schema.Finite),
    min: Schema.optionalKey(Schema.Finite),
    max: Schema.optionalKey(Schema.Finite),
    minItems: Schema.optionalKey(Schema.Finite),
    maxItems: Schema.optionalKey(Schema.Finite),
    options: Schema.optionalKey(Schema.Array(OptionSchema)),
    format: Schema.optionalKey(Schema.Literals(['email', 'url', 'date'])),
});
export const FieldDefinitionSchema = Schema.Struct({
    name: Schema.String,
    type: Schema.Literals(['string', 'integer', 'number', 'boolean', 'date', 'enum', 'file', 'array', 'object']),
    component: Schema.String,
    label: Schema.String,
    helpText: Schema.optionalKey(Schema.String),
    props: JsonObjectSchema,
    constraints: ConstraintsSchema,
    nullable: Schema.Boolean,
    serverRules: Schema.Array(Schema.String),
});
export const GroupDefinitionSchema = Schema.Struct({
    component: Schema.String,
    label: Schema.optionalKey(Schema.String),
    helpText: Schema.optionalKey(Schema.String),
    fields: Schema.Record(Schema.String, Schema.String),
    props: JsonObjectSchema,
});
export const FormMetadataSchema = Schema.Struct({
    id: Schema.String,
    defaultValues: JsonObjectSchema,
    fields: Schema.Record(Schema.String, FieldDefinitionSchema),
    groups: Schema.Record(Schema.String, GroupDefinitionSchema),
});
export const ExtractionSchema = Schema.Struct({
    version: Schema.Literal(1),
    forms: Schema.Array(FormMetadataSchema),
    diagnostics: Schema.Array(Schema.String),
}).annotate({ message: 'Invalid or unsupported Formbraid source export.' });
const HttpMethodSchema = Schema.Literals(['get', 'post', 'put', 'patch', 'delete']);
export const SubmissionTargetSchema = Schema.Struct({ url: Schema.String, method: HttpMethodSchema });
export const SubmissionBindingSchema = Schema.Struct({ driver: Schema.String, binding: JsonValueSchema });
/** Only the serializable named-driver branch crosses a JSON boundary. */
export const FormDescriptorSchema = Schema.Struct({
    version: Schema.Literal(1),
    definition: FormMetadataSchema,
    defaultValues: Schema.optionalKey(JsonObjectSchema),
    submission: SubmissionBindingSchema,
});
export const HttpOperationSchema = Schema.Struct({
    uri: Schema.String,
    method: HttpMethodSchema,
});
export const OperationParameterSchema = Schema.Struct({
    name: Schema.String,
    optional: Schema.optionalKey(Schema.Boolean),
});
export function operationSchema(binding) {
    return Schema.Struct({
        name: Schema.String,
        schema: Schema.String,
        parameters: Schema.Array(OperationParameterSchema),
        binding,
    });
}
const RecordSchema = Schema.Record(Schema.String, Schema.Unknown);
export const isRecord = Schema.is(RecordSchema);
export const isJsonValue = Schema.is(JsonValueSchema);
const extractionJson = Schema.fromJsonString(ExtractionSchema);
const descriptorJson = Schema.fromJsonString(FormDescriptorSchema);
const jsonValueJson = Schema.fromJsonString(JsonValueSchema);
const decodeOptions = { errors: 'all', onExcessProperty: 'error' };
/** Native decoders retain structured schema failures for Effect workflows. */
export const parseExtractionEffect = Schema.decodeUnknownEffect(extractionJson, decodeOptions);
export const parseJsonValueEffect = Schema.decodeUnknownEffect(jsonValueJson, decodeOptions);
export const parseFormDescriptorEffect = Schema.decodeUnknownEffect(descriptorJson, decodeOptions);
export function parseFormDescriptor(json) {
    return Effect.runSync(parseFormDescriptorEffect(json));
}
/** Synchronous compiler/API boundaries execute the same native decoder. */
export function parseExtraction(json) {
    return Effect.runSync(parseExtractionEffect(json));
}
export function parseJsonValue(json) {
    return Effect.runSync(parseJsonValueEffect(json));
}
