import type { SubmissionContext, SubmissionDriver, SubmissionResult } from './contracts.js';
import { Effect } from 'effect';
/** Adapt a typed binding executor to the portable runtime boundary. */
export declare function defineSubmissionDriver<TBinding>(options: {
    readonly accepts: (binding: unknown) => binding is TBinding;
    readonly submit: (context: Omit<SubmissionContext, 'binding'> & {
        readonly binding: TBinding;
    }) => Effect.Effect<SubmissionResult>;
}): SubmissionDriver;
